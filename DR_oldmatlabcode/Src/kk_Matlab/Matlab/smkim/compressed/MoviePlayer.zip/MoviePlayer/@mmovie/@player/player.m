function H = player(h,fcns)
%PLAYER Constructor for movie Player object

H = mmovie.player;
H.hfig = h;
H.fcns = fcns;
