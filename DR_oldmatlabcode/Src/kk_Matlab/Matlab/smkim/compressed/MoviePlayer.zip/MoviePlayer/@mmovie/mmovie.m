function MMovie
%MMOVIE Constructor for MMOVIE package.

