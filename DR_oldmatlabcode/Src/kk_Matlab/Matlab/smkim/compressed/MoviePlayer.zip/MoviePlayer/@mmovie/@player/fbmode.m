function fbmode(H)
%FBMODE Toggle forward-backward playback mode of movie in movie player

feval(H.fcns.fbmode,[],[],H.hfig);
