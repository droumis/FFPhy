function schema
% Schema for the MOVIE package.
  
%   Copyright 2003 The MathWorks, Inc.
%   $Revision: $  $Date: $

schema.package('mmovie');
