function truesize(H)
%TRUESIZE Shrink movie to minimum pixel size

feval(H.fcns.truesize,[],[],H.hfig);
