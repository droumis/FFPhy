function loop(H)
%LOOP Toggle looping playback of movie in movie player

feval(H.fcns.loop,[],[],H.hfig);
