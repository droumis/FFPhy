A = magic(4)

B = demomex(A)
