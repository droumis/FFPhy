
mex demomex.cpp newdelete.cpp