%  book_2_25.m

load fusion

slplot(NV,VV)
title('Fusion Time (seconds)')

