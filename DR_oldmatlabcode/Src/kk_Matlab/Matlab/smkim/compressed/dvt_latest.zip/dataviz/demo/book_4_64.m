%  book_4_64.m

load soil

plot(Easting,Northing,'.')
axis('equal')
xlabel('Easting (km)')
ylabel('Northing (km)')
title('Soil')
axis tight