function T = tokenize(S,D)
%TOKENIZE          Break string into tokens.
%   T = TOKENIZE(S) returns a cell array T containing the tokens of S,
%   delimited by white space.
%
%   T = TOKENIZE(S,D) uses the characters of D as delimiters.
%
%   Either syntax ignores any leading delimiters.
%
%   Example:
%      TOKENIZE('  The quick brown') gives {'The','quick','brown'}.
%      TOKENIZE('1;20;300',';') gives {'1','20','300'}.
%
%   See also STRTOK.

%%%%%%%%%%%%%%%%%%%%%%%%%%%% Parse Inputs %%%%%%%%%%%%%%%%%%%%%%%%%%%%
if (nargin < 2), D = sprintf(' \t\r\n\f');  end;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Processing %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
T = {};
while (~isempty(S)),  [T{end+1},S] = strtok(S,D);   end