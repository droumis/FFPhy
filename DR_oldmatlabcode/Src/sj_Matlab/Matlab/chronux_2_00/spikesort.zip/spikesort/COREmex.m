function COREmex(source, options)
%COREMEX           Compile CORE_ functions.
%   COREMEX(SOURCE), where SOURCE is the name of a CORE_ source
%   file, checks if the .dll file of the same name is older than any of
%   the following source files: {SOURCE, CORE_library.c, CORE_mextools.c}.
%   If any of these files have been modified since the .dll was created
%   (or if no such .dll exists), COREMEX calls:
%         mex SOURCE CORE_library.c CORE_mextools.c LAPACK
%   where LAPACK is the static LAPACK library definition file for the
%   currently chosen compiler.  This compiles the MEX code in SOURCE
%   and links to both CORE_library functions and BLAS/LAPACK.
%   
%   COREMEX(SOURCE, OPTIONS) allows specification of command line options
%   to be passed to MEX.
%
%   Example:
%      If the current compiler is set to be LCC and CORE_testfile.c has
%      been modified since CORE_testfile.dll was created (i.e., 'Modified'
%      in Windows),
%          COREmex('CORE_testfile.c', '-v -g')
%      calls
%          mex -v -g CORE_testfile.c ...
%                      CORE_library.c CORE_mextools.c lcc_libmwlapack.lib
%
%      If not using the OPTIONS argument, the following syntax is valid:
%          COREMEX CORE_testfile.c

%%%%%%%%%%%%%%%%%%%%%%%%%%%% Parse Inputs %%%%%%%%%%%%%%%%%%%%%%%%%%%%
if (nargin < 2),  options = '';  end
[pat,nam,ext] = fileparts(source);
if (~exist(source, 'file')),
	error(['Source file ' SOURCE ' not found.']);
end

%%%%%%%%%%%%%%%%%%%%%% Check if Compile Needed %%%%%%%%%%%%%%%%%%%%%%%
src1 = dir(source);
src2 = dir('CORE_library.c');
src3 = dir('CORE_mextools.c');
dll = dir([pat nam '.dll']);
if (~isempty(dll))
	srclist = [datenum(src1.date) datenum(src2.date) datenum(src3.date)];
	if (all(datenum(dll.date) > srclist)),  return;   end
end

%%%%%%%%%%%%%%%%%%%%% Choose LAPACK definitions %%%%%%%%%%%%%%%%%%%%%%
% We need to figure out which compiler we're using so we can link the
% appropriate static LAPACK library definition ...
[stat,rslt] = system('echo %USERPROFILE%');
mexopts = [rslt(1:end-1) '\Application Data\Mathworks\MATLAB\R13\mexopts.bat'];
origname = textread(mexopts, 'rem %s', 1, 'headerlines', 1);
switch (upper(origname{1}(1:3)))
	case 'MSV', lapack = 'msvc_libmwlapack.lib';
	case 'BCC', lapack = 'borland_libmwlapack.lib';
	case 'LCC', lapack = 'lcc_libmwlapack.lib';
	otherwise,  error('Do not have the static LAPACK definition for that compiler.');
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Compile %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
eval(['mex ' options ' ' source ' CORE_library.c CORE_mextools.c ' lapack]);
