/*
 *  Locfit, Matlab version.
 *  See README file for more information.
 *
 *  Copyright (c) 2006, Catherine Loader.
 *  http://locfit.herine.net
 *  Author: Catherine Loader, lf@herine.net
 *
 */
/*=================================================================
 * mexlocfit.c 
 *
 * starting a locfit interface.
 *
/* $Revision: 1.5 $ */
#include "mex.h"
#include "local.h"

design des;
lfit lf;
int lf_error;
extern int lf_debug;

extern void lfmxdata(), lfmxsp(), lfmxevs();

void
mexFunction(int nlhs,mxArray *plhs[],int nrhs,const mxArray *prhs[])
{
    int  d, i, nvc[5], nvm, vc, nv, nc, mvc, lw[7];
    double *y;
    mxArray *iwkc;

    if (nrhs != 3) mexErrMsgTxt("mexlf requires 3 inputs.");
    lf_error = 0;

    lfit_alloc(&lf);
    lfit_init(&lf);

    lfmxdata(&lf.lfd,prhs[0]);
    d = lf.lfd.d;
    lfmxsp(&lf.sp,prhs[2],d);
    lfmxevs(&lf,prhs[1]);

    guessnv(&lf.evs,&lf.sp,&lf.mdl,lf.lfd.n,d,lw,nvc);

    nvm = lf.fp.nvm = nvc[0];
    vc = nvc[2];
    if (ev(&lf.evs) != EPRES) lf.fp.xev = mxCalloc(nvm*d,sizeof(double));
    lf.fp.lev = nvm*d;
    lf.fp.coef = mxCalloc(lw[1],sizeof(double));
    lf.fp.lwk = lw[1];
    lf.evs.iwk = mxCalloc(lw[2],sizeof(int));
    lf.evs.liw = lw[2];
    plhs[1] = mxCreateDoubleMatrix(1,lw[3],mxREAL);
    lf.pc.wk = mxGetPr(plhs[1]);
    lf.pc.lwk = lw[3];
    lf.fp.kap = mxCalloc(lw[5],sizeof(double));
/* should also allocate design here */
    
/* startmodule calls locfit to do the fitting. Skip
   the startmodule, initmodule step, as it's already
   initialized. */
    lf.mdl.pp(&lf,&des);

/* now, store the results:
   plhs[0] stores informtion about fit points and evaluation structure.
   {0} - matrix of evaluation points.
   {1} - matrix fitted values etc.
   {2} - cell of 'integer' vectors {ce,s,lo,hi}
   {3} - fit limit (matrix with 2 cols).
   {4} - [familt link] numeric vector.
   {5} - kap vector.
*/
    plhs[0] = mxCreateCellMatrix(6,1);

    mxSetCell(plhs[0],0,mxCreateDoubleMatrix(d,lf.fp.nv,mxREAL));
    memcpy(mxGetPr(mxGetCell(plhs[0],0)), lf.fp.xev, d*lf.fp.nv*sizeof(double));

    mxSetCell(plhs[0],1,mxCreateDoubleMatrix(lf.fp.nv,lf.mdl.keepv,mxREAL));
    for (i=0; i<lf.mdl.keepv; i++)
      memcpy(&mxGetPr(mxGetCell(plhs[0],1))[i*lf.fp.nv], &lf.fp.coef[i*nvm], lf.fp.nv*sizeof(double));
    /* another bit to save here? -- split values, kdtree */
   
    mxSetCell(plhs[0],2,mxCreateCellMatrix(4,1));
    iwkc = mxGetCell(plhs[0],2);
    nv = lf.fp.nv;
    nc = lf.evs.nce;
    mvc = (nv>nc) ? nv : nc;
    mxSetCell(iwkc,0,mxCreateDoubleMatrix(vc,nc,mxREAL));  /* ce */
    mxSetCell(iwkc,1,mxCreateDoubleMatrix(1,mvc,mxREAL));  /* s  */
    mxSetCell(iwkc,2,mxCreateDoubleMatrix(1,mvc,mxREAL));  /* lo */
    mxSetCell(iwkc,3,mxCreateDoubleMatrix(1,mvc,mxREAL));  /* hi */
    y = mxGetPr(mxGetCell(iwkc,0));
    for (i=0; i<vc*nc; i++) y[i] = lf.evs.ce[i];
    y = mxGetPr(mxGetCell(iwkc,1));
    for (i=0; i<mvc; i++) y[i] = lf.evs.s[i];
    y = mxGetPr(mxGetCell(iwkc,2));
    for (i=0; i<mvc; i++) y[i] = lf.evs.lo[i];
    y = mxGetPr(mxGetCell(iwkc,3));
    for (i=0; i<mvc; i++) y[i] = lf.evs.hi[i];

    mxSetCell(plhs[0],3,mxCreateDoubleMatrix(d,2,mxREAL));
    memcpy(mxGetPr(mxGetCell(plhs[0],3)), lf.evs.fl, 2*d*sizeof(double));
    
    mxSetCell(plhs[0],4,mxCreateDoubleMatrix(1,2,mxREAL));
    y = mxGetPr(mxGetCell(plhs[0],4));
    y[0] = fam(&lf.sp);
    y[1] = link(&lf.sp);

    mxSetCell(plhs[0],5,mxCreateDoubleMatrix(1,lf.mdl.keepc,mxREAL));
    memcpy(mxGetPr(mxGetCell(plhs[0],5)),lf.fp.kap,lf.mdl.keepc*sizeof(double));
}
