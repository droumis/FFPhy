function y = fitted(fit)
% Fitted values from a locfit object.
%
% Usage:y = fitted(fit)
%
% Input arguments:
%   fit - the locfit() fit.
%
%  Author: Catherine Loader.

y = predict(fit,'d','restyp','fit');

return;


