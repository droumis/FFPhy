% Local Regression and Likelihood, Figure 13.1.
% Author: Catherine Loader
%
% Minimax local regression.

load mmsamp;
fit = locfit(x,y,'deg',1,'kern','minmax','alpha',4000,'ev','grid','mg',200,'ll',0,'ur',1);
x0 = fit{4}{1};
y0 = predict(fit);
plot(x0,y0);
hold on;
fit = locfit(x,y,'deg',1,'h',0.05,'ev','grid','mg',200,'ll',0,'ur',1);
x0 = fit{4}{1};
y0 = predict(fit);
plot(x0,y0,'color','red');

x1 = 0:0.01:1;
y1 = 2-5*x1+5*exp(-(20*x1-10).^2);
plot(x1,y1,'color','green');

legend('Minimax','Constant h','True mean');

plot(x,y,'.');

hold off;
