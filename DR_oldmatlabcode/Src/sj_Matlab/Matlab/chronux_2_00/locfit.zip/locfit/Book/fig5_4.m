% Local Regression and Likelihood, Figure 5.4.
% Author: Catherine Loader
%
% Bivariate Density Estimation.

load trimod;
fit = locfit([x0 x1],'alpha',0.35);
lfplot(fit);