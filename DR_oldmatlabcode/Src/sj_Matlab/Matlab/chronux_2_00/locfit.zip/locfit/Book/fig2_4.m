% Local Regression and Likelihood, Figure 3.1.
%
% Bivariate Local Regression.

load ethanol;

alp = [0.25 0.3 0.49 0.59];
lab = {'Local Constant' 'Local Linear' 'Local Quadratic' 'Local Cubic'};
for i = 1:4
    figure(i)
    fit = locfit(E,NOx,'deg',i-1,'alpha',alp(i));
    lfplot(fit);
    title(lab(i));
end;
