% Local Regression and Likelihood, Figure 4.3.
% Author: Catherine Loader
%
% Residual plots for local likelihood.
% Henderson-Shepherd Mortality Data.

load morths;
fit = locfit(age,deaths,'weights',n,'family','binomial','alpha',0.5);

figure(1);
plot(age,residuals(fit,'dev'),'.-');
xlabel('Age');
ylabel('Residual');
title('Deviance Residuals');
hold on;
plot([min(age) max(age)],[0 0],':');
hold off;

figure(2);
plot(age,residuals(fit,'pear'),'.-');
xlabel('Age');
ylabel('Residual');
title('Pearson Residuals');
hold on;
plot([min(age) max(age)],[0 0],':');
hold off;

figure(3);
plot(age,residuals(fit,'raw'),'.-');
xlabel('Age');
ylabel('Residual');
title('Raw (response) Residuals');
hold on;
plot([min(age) max(age)],[0 0],':');
hold off;

figure(4);
plot(age,residuals(fit,'ldot'),'.-');
xlabel('Age');
ylabel('Residual');
title('ldot Residuals');
hold on;
plot([min(age) max(age)],[0 0],':');
hold off;

