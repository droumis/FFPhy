% Local Regression and Likelihood, Figure 9.1.
%
% Hardle's Motorcycle accelaration dataset. Just a scatterplot!
%
% Author: Catherine Loader

load mcyc;
plot(time,accel,'.');
xlabel('Time');
ylabel('Acceleration');
