/*
 *  Locfit, Matlab version.
 *  See README file for more information.
 *
 *  Copyright (c) 2006, Catherine Loader.
 *  http://locfit.herine.net
 *  Author: Catherine Loader, lf@herine.net
 *
 */
#include "mex.h"
#include "local.h"

void lfmxdata(lfdata *lfd, const mxArray *data)
{ const mxArray *tmp;
  double *x, *sc, *xl;
  int n, d, i, k;
  char c, ststr[16];
  
  n = lfd->n = mxGetM(mxGetCell(data,0));
  d = lfd->d = mxGetN(mxGetCell(data,0));
  x = mxGetPr(mxGetCell(data,0));
  for (i=0; i<d; i++) lfd->x[i] = &x[i*n];
  
  lfd->y = mxGetPr(mxGetCell(data,1));
  
  tmp = mxGetCell(data,2);
  k = mxGetM(tmp);
  lfd->w = (k>1) ? mxGetPr(tmp) : NULL;

  tmp = mxGetCell(data,3);
  k = mxGetM(tmp);
  lfd->c = (k>1) ? mxGetPr(tmp) : NULL;

  tmp = mxGetCell(data,4);
  k = mxGetM(tmp);
  lfd->b = (k>1) ? mxGetPr(tmp) : NULL;

  mxGetString(mxGetCell(data,5),ststr,16);
  k = strlen(ststr);
  for (i=0; i<d; i++)
  { c = (k==1) ? ststr[0] : ststr[i];
    switch(c)
    { case 'a': lfd->sty[i] = STANGL; break;
      case 'l': lfd->sty[i] = STLEFT; break;
      case 'r': lfd->sty[i] = STRIGH; break;
      case 'c': lfd->sty[i] = STCPAR; break;
      default:  lfd->sty[i] = 1; break;
    }
  }

  sc = mxGetPr(mxGetCell(data,6));
  k = mxGetN(mxGetCell(data,6));
  for (i=0; i<d; i++) lfd->sca[i] = (k==1) ? sc[0] : sc[i];

  xl = mxGetPr(mxGetCell(data,7));
  for (i=0; i<d; i++)
  { lfd->xl[i] = xl[2*i];
    lfd->xl[i+d] = xl[2*i+1];
  }
}

void lfmxsp(smpar *sp, mxArray *mcell, int d)
{ double *alpha;
  char str[16];

  alpha = mxGetPr(mxGetCell(mcell,0));
  nn(sp)  = alpha[0];
  fixh(sp)= alpha[1];
  pen(sp) = alpha[2];

  mxGetString(mxGetCell(mcell,1),str,16);
  acri(sp) = lfacri(str);

  deg(sp) = mxGetPr(mxGetCell(mcell,2))[0];
  deg0(sp) = -1;

  mxGetString(mxGetCell(mcell,3),str,16);
  fam(sp) = lffamily(str);
  mxGetString(mxGetCell(mcell,4),str,16);
  link(sp) = lflink(str);
  setfamily(sp);

  mxGetString(mxGetCell(mcell,5),str,16);
  ker(sp) = lfkernel(str);
  mxGetString(mxGetCell(mcell,6),str,16);
  kt(sp) = lfketype(str);
  npar(sp) = calcp(sp,d);
}

void lfmxevs(lfit *lf, mxArray *mcell)
{ int d, i, j;
  double *ll, *ur, *mg, *drv;
  char evstr[16], mod[16];
  evstruc *evs;
  fitpt *fp;
  deriv *dv;

  evs = &lf->evs;
  fp  = &lf->fp;
  dv  = &lf->dv;
  d   = lf->lfd.d;

  if (mxIsChar(mxGetCell(mcell,0)))
  { mxGetString(mxGetCell(mcell,0),evstr,16);
    ev(evs) = lfevstr(evstr);
  }
  else
  { ev(evs) = EPRES;
    evs->mg[0] = mxGetN(mxGetCell(mcell,0));
    fp->xev = mxGetPr(mxGetCell(mcell,0));
  }

  mxGetString(mxGetCell(mcell,1),mod,16);
  initmodule(&lf->mdl,mod,NULL,lf->lfd.n,d);

  ll = mxGetPr(mxGetCell(mcell,2));
  ur = mxGetPr(mxGetCell(mcell,3));
  mg = mxGetPr(mxGetCell(mcell,4));
  j =  mxGetN(mxGetCell(mcell,4));
  cut(evs) = mxGetPr(mxGetCell(mcell,5))[0];
  for (i=0; i<d; i++)
  { evs->fl[i] = ll[i];
    evs->fl[i+d] = ur[i];
    if (ev(evs) != EPRES) evs->mg[i] = (j==1) ? mg[0] : mg[i];
  }
  mk(evs) = mxGetPr(mxGetCell(mcell,6))[0];

  drv = mxGetPr(mxGetCell(mcell,7)); 
  j = mxGetN(mxGetCell(mcell,7)); 
  for (i=0; i<j; i++) dv->deriv[i] = drv[i]-1;
  dv->nd = (drv[0]>0) ? j : 0;
}
