/*
 *  Locfit, Matlab version.
 *  See README file for more information.
 *
 *  Copyright (c) 2006, Catherine Loader.
 *  http://locfit.herine.net
 *  Author: Catherine Loader, lf@herine.net
 *
 */
/*=================================================================
 * mexpp.c 
 *
 * starting a locfit interface.
 *
 * $Revision: 1.5 $ */
#include "mex.h"
#include "local.h"
FILE *tmp;

extern void lfmxdata(), lfmxevs();

design des;
lfit lf;
int lf_error;
extern int lf_debug;


void mexFunction(int nlhs,mxArray *plhs[],int nrhs,const mxArray *prhs[])
{ int i, vc, nc, mvc, mg[MXDIM], where, m, wh, dir, nkap;
  const mxArray *dat, *fpc, *sp, *pc, *evs, *iwkc;
  double *y, *x, *fy, *fx[MXDIM], *kap, cv, *fh, *se, *lo, *hi, lev;
  char band[16], wher[16], what[16], rest[16];

  if (nrhs<6) mexErrMsgTxt("ppmex requires 5 inputs.");
  lf_error = 0;

  dat= mxGetCell(prhs[1],0);
  evs= mxGetCell(prhs[1],1);
  sp = mxGetCell(prhs[1],2);
  fpc= mxGetCell(prhs[1],3);
  pc = mxGetCell(prhs[1],4);
  mxGetString(prhs[2],band,16);
  mxGetString(prhs[3],what,16);
  mxGetString(prhs[4],rest,16);
  dir = mxGetPr(prhs[5])[0];
  kap = mxGetPr(prhs[6]);
  nkap = mxGetN(prhs[6]);
  lev = mxGetPr(prhs[7])[0];

  lfmxdata(&lf.lfd,dat);
  lfmxsp(&lf.sp,sp,lf.lfd.d);
  lfmxevs(&lf,evs);

  if (rest[0]=='n')
    wh = ppwhat(what);
  else
    wh = 64+restyp(rest);
   
    lf.fp.xev = mxGetPr(mxGetCell(fpc,0));
    lf.lfd.d = lf.fp.d = mxGetM(mxGetCell(fpc,0));
    lf.fp.nv = lf.fp.nvm = mxGetN(mxGetCell(fpc,0));
    lf.fp.coef = mxGetPr(mxGetCell(fpc,1));
    lf.fp.nlx = &lf.fp.coef[(1+lf.fp.d)*lf.fp.nv];
    lf.fp.t0  = &lf.fp.nlx[(1+lf.fp.d)*lf.fp.nv];
    lf.fp.lik = &lf.fp.t0[(1+lf.fp.d)*lf.fp.nv];
    lf.fp.h   = &lf.fp.lik[3*lf.fp.nv];
    lf.fp.deg = &lf.fp.h[lf.fp.nv];
        
    iwkc = mxGetCell(fpc,2);
    vc = mxGetM(mxGetCell(iwkc,0));
    nc = mxGetN(mxGetCell(iwkc,0));
    mvc = mxGetN(mxGetCell(iwkc,1));
    lf.evs.iwk = mxCalloc(vc*nc+3*mvc,sizeof(int));
    lf.evs.nce = lf.evs.ncm = nc;
    y = mxGetPr(mxGetCell(iwkc,0));
    lf.evs.ce = lf.evs.iwk;
    for (i=0; i<vc*nc; i++) lf.evs.ce[i] = y[i];
    y = mxGetPr(mxGetCell(iwkc,1));
    lf.evs.s = &lf.evs.iwk[vc*nc];
    for (i=0; i<mvc; i++) lf.evs.s[i] = y[i];
    y = mxGetPr(mxGetCell(iwkc,2));
    lf.evs.lo = &lf.evs.s[mvc];
    for (i=0; i<mvc; i++) lf.evs.lo[i] = y[i];
    y = mxGetPr(mxGetCell(iwkc,3));
    lf.evs.hi = &lf.evs.lo[mvc];
    for (i=0; i<mvc; i++) lf.evs.hi[i] = y[i];
    lf.fp.hasd = deg(&lf.sp)>0;

    lf.fp.kap = mxGetPr(mxGetCell(fpc,5));

    lf.pc.wk = mxGetPr(pc);
    lf.pc.lwk = mxGetN(pc);
    pcchk(&lf.pc,lf.fp.d,npar(&lf.sp),1);
    haspc(&lf.pc) = !noparcomp(&lf.sp);
    lf.pc.xtwx.st = JAC_EIGD;
    
  where = 0;
  if (mxIsCell(prhs[0])) /* interpret as grid margins */
  { m = 1;
    for (i=0; i<lf.fp.d; i++)
    { fx[i] = mxGetPr(mxGetCell(prhs[0],i));
      mg[i] = mxGetM(mxGetCell(prhs[0],i));
      m *= mg[i];
    }
    where = 2;
  }
  if (mxIsChar(prhs[0]))
  { mxGetString(prhs[0],wher,16);
    where = 3; /* data */
    m = mg[0] = lf.lfd.n;
    if (wher[0] == 'f') /* or fit points */
    { where = 4;
      m = mg[0] = lf.fp.nv;
    }
  }
  if (where==0)                   /* interpret as numeric vector */
  { x = mxGetPr(prhs[0]);
    m = mg[0] = mxGetM(prhs[0]); /* should check mxGetN == d */
    for (i=0; i<lf.lfd.d; i++)
      fx[i] = &x[i*m];
    where=1;
  }

  plhs[0] = mxCreateDoubleMatrix(m,1,mxREAL); /* fitted values */
  plhs[1] = mxCreateDoubleMatrix(m,1,mxREAL); /* std errors */
  fh = mxGetPr(plhs[0]);
  se = mxGetPr(plhs[1]);

  preplot(&lf,fx,fh,se,band[0],mg,where,wh,dir);

  cv = 0.0;
  if (band[0] != 'n')
  { cv = critval(1-lev,kap,nkap,lf.lfd.d,TWO_SIDED,0.0,GAUSS);
    plhs[2] = mxCreateDoubleMatrix(m,2,mxREAL);
    lo = mxGetPr(plhs[2]);
    hi = &lo[m];
    for (i=0; i<m; i++)
    { lo[i] = fh[i]-cv*se[i]; 
      hi[i] = fh[i]+cv*se[i]; 
    }
  }
  else plhs[2] = mxCreateDoubleScalar(0.0);
}
