function out = getindex(index, excludetimes)
% out = getindex(index, excludetimes)
% Returns the index of the cell

out = index;

