function animalinfo = animaldef(animalname)

switch lower(animalname)
    case 'frank'
        animalinfo = {'Frank', 'G:\Data\Fra\', 'fra'};
    case 'miles'
        animalinfo = {'Miles', 'G:\Data\Mil\', 'mil'};
    case 'nine'
        animalinfo = {'Nine', 'G:\Data\Nin\', 'nin'};
    case 'ten'
        animalinfo = {'Ten', 'G:\Data\Ten\', 'ten'};
    case 'dudley'
        animalinfo = {'Dudley', 'G:\Data\Dud\', 'dud'};
    case 'alex'
        animalinfo = {'Alex', 'G:\Data\Ale\', 'ale'};
    case 'conley'
        animalinfo = {'Conley', 'G:\Data\Conl\', 'con'};
    case 'bond'
        animalinfo = {'Bond', 'G:\Data\Bon\', 'bon'};
    otherwise
        error(['Animal ',animalname, ' not defined.']);
end