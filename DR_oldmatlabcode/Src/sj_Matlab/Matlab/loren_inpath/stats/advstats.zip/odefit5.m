%odefit5.m SCRIPT for ver 5.0
%USES curvefit  ode45 & XPRIME TO FIT PARAM IN ODES (STATS ASSIG 4A)

% DATA points
tspan=[0 10 20 40 80 160 320]';
yd=[0 .19 .14 .42 .42 .41 .27]';
yd1=[0 .14 .24 .3 .4 .46 .22]';
% take ave of y data
yd=(yd+yd1).*0.5;
% Initial Conditions for odes
x0=[1 0]';
% Initial parameter guess
%disp(' enter two values for parms k1 k2')
k0=[.001 .003]

% optimisation model is 'modode5' here--- it in turn calls ode45
% x0 is extra passed param
[kfinal,options,error,jac]=curvefit('modode5',k0,tspan,yd,[],[],x0);
kfinal
ymodel=yd+error;
figure
plot(tspan,ymodel,tspan,yd,'o')
grid
xlabel('time t');ylabel('y or x2')
title('fitted - , vs data o')

