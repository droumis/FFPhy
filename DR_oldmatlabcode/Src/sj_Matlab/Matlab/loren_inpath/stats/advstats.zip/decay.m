function q=decay(p,x)
t=x(:,1);data=x(:,2);
a=p(1);b=p(2);
q=exp(-a*t).*sin(2*pi*b*t)-data;
q=sum(q.^2);
