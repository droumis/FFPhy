function  z=tsim(B,F,C,D,va,A1,C1,ve,n)
%z =tsim(B,F,C,D,va,A1,C1,ve,n)
% Function to simulate various time series see	idsim in ident tool box
%  OUT:     z= [y u]
% Model :  y= B/F*u(t-n) + C/D*a(t)
%	   A1*u= C1*e(t)	  here F,B=[], D=1
%
%leading n zeros in B shows delays u(t-n) : B=[0 0 ..b1 b2]
% D F and A1  start with 1:  eg F=[1 f1...], etc
% va = variance(a(t))
% ve = variance(e(t))
% n   = number of data pts



t=(1:n)';	    % generate time steps
a=randn(n,1);% unit variance for norm rand #'s, variance specified in poly2th
e=randn(n,1);
%
% model specs for y(t)
%

thy= poly2th(1,B,C,D,F,va);	% A=1 here
%
% model specs for u(t)
%
%	   A1*u= C1*e(t)	  here F,B=[] ,D=1
%
thu=poly2th(A1,[],C1,1,[],ve);
%    input (u) time series
u=idsim(e,thu);
%    output (y) time series
y=idsim([u,a],thy);
%
z=[y,u];
idplot(z)
	  pause
disp('to save use : save ts?.dat z  /ascii')
