function y=yrsm(x,b0,b,BF)
% MAKE SURE YOU USE FULL B (not B from leasqr1 =lower B)
xc=x';

if nargin > 1 , b0_=b0;b_=b;B_=BF; end
y=b0_ + xc*b_' +xc*B_*xc'; % calc y for rsm model
