 % script leasq example using curvefit
% generate some data
t=[0.:.01:1]';
p=[4 5];
y=exp(-p(1)*t).*sin(2*pi*p(2)*t);
yd=y+.01*randn(size(y));  %add noise
p0=[2	3];	  %initial guess for paprameters
[pfinal,options,error,jac]=curvefit('modelcurve',p0,t,yd);
pfinal
ymodel=yd+reshape(error,size(yd));% error vector needs reshaping

% calc regression data
[std,varresid,r2,cor,vcv,varinf]=regdata(pfinal,ymodel,yd,jac);
figure
plot(t,ymodel,t,yd,'o')
grid
xlabel('time t');ylabel('y ')
title('fitted - , vs data o')