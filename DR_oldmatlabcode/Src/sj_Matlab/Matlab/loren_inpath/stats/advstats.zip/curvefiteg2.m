 % script leasq example using curvefit
% generate some data for two t's
t1=[0.01:.01:1]';t2=[0.01:.01:1]'.*2;t=[t1,t2];
p=[.4 .5];% parameters
y=exp(-p(1).*t(:,1)).*sin(2*pi*p(2).*t(:,2));
yd=y+.01*randn(size(y));  %add noise
p0=[.3 .4]';	  %initial guess for parameters
[pfinal,options,error,jac]=curvefit('modelcurve2',p0,t,yd);
pfinal
ymodel=yd+reshape(error,size(yd));% error vector needs reshaping

% calc regression data
[std,varresid,r2,cor,vcv,varinf]=regdata(pfinal,ymodel,yd,jac);
