function y=mdlnlin(p,t)
y=exp(-p(1)*t).*sin(2*pi*p(2)*t);
return
