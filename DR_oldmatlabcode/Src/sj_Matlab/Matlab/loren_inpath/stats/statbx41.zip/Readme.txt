STATBOX 4.1

This is a library of MATLAB statistical routines.  See the file
contents.m for a table of contents.  The homepage of Statbox is at
http://www.maths.uq.edu.au/~gks/matlab/statbox.html.  Please check
the homepage to see that you have the latest version of the software.

Unless otherwise indicated, routines were written by me.  Thanks and
acknowledgements to:

   Howard Wilson, University of Alabama
      (for grule, gquad)
   Roger B Sidje, University of Queensland
      (for expv, mexpv)
   Mohamad A Akra, Massachussets Institute of Technology
      (for diagsum)

To install the library you must

1.  Copy the files to a convenient directory
2.  Add the directory to the matlabpath

Under Microsoft Windows 3.1 you can achieve this effect by
1.  Coping all files to a directory, c:\statbox say
2.  Edit the file c:\statbox\startup.m so that it contains the line
    "matlabpath(['c:\statbox;' matlabpath]);"
3.  Edit the properties of the MATLAB icon to make c:\statbox the
    working directory.

Please direct any problems to me:

Gordon K Smyth
gks@maths.uq.edu.au
Department of Mathematics, Unversity of Queensland, Q 4072, Australia
http://www.maths.uq.edu.au/~gks/

7 Dec 98
