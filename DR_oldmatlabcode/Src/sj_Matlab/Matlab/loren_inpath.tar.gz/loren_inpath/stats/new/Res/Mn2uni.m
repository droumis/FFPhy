% MN2UNI: Calculates the mean of the SQUARED uniform distribution U[0,1] 
%         within the interval [p,q]
