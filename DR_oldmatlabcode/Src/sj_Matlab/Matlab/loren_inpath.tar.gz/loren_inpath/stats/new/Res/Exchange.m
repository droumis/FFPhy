% EXCHANGE: Exchanges of the values of two variables.
%
%     Usage: [b,a] = exchange(a,b)
%

function [b,a] = exchange(a,b)
  return;

