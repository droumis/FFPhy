% WORDPLOT: Reset line widths for plots to be copied to Word documents

set(0,'DefaultLineLineWidth',1.35);      % Line plot width
set(0,'DefaultAxesLineWidth',1.35);      % Axis line width
