% Phi: returns the value of phi, the golden proportion
%

function p = phi
  p = (1+sqrt(5))./2;
  return;
