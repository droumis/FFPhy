% THINLINES: Set global graphics defaults for thin lines.
%

set(0,'DefaultLineLineWidth','default');       % Line plot width
set(0,'DefaultAxesLineWidth','default');       % Axis line width
