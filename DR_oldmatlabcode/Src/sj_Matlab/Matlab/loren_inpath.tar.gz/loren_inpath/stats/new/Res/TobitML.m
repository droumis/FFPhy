% TOBITML: Maximum-likelihood solution of the Tobit model.
%
%     Usage: 