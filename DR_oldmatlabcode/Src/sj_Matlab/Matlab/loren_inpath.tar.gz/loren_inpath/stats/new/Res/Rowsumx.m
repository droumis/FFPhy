% rowsum script file
%
%   assumes that the input matrix is 'x', and the output matrix is 'rs'

rs = sum(x')';
rsum = sum(rs);